# TOCFL Vocabulary by Band — 2024-09-23

This package is for the website vocabulary study mode **"Học theo Band TOCFL"**.

## Canonical import files

- `catalog.json` — bands, levels, counts, provenance, and import rules.
- `entries.json` — the canonical 7517 vocabulary records to import.
- `schema/entry.schema.json` — validation schema for each vocabulary entry.
- `supplemental/cross-strait-terms.json` — reference aliases only.
- `source/TOCFL_8000_20240923.xlsx` — original source workbook for audit/reference.

## Website navigation

The workbook itself is organized by levels, not by a single `band` column.
For this website, group the source levels as:

- **Band Novice**
  - Novice 1 / 準備級一級 — 160 entries
  - Novice 2 / 準備級二級 — 234 entries
  - Total in this band: 394

- **Band A**
  - Level 1 / 入門級 — 347 entries
  - Level 2 / 基礎級 — 485 entries
  - Total in this band: 832

- **Band B**
  - Level 3 / 進階級 — 1173 entries
  - Level 4 / 高階級 — 2342 entries
  - Total in this band: 3515

- **Band C**
  - Level 5 / 流利級 — 2776 entries
  - The supplied source contains no separate Level 6 sheet. **Do not invent one.**

Total imported source entries: **7517**.

## Critical data rules

1. **Do not deduplicate by vocabulary text.**
   The same written form can legitimately appear at multiple levels with a different
   part of speech or usage. This source contains 298 written forms
   that appear in more than one level.

2. Use `entry.id` as the stable key for:
   - learning progress
   - favorites
   - spaced repetition state
   - notes
   - learned/unlearned status

   Do not use the Chinese word itself as the database primary key.

3. `traditional` is the official source-of-truth term from the workbook.

4. `simplified` is a derived **character conversion of the same Taiwanese/TOCFL term**.
   It is not a Mainland vocabulary replacement.

5. The workbook includes `兩岸常用詞語差異表`. Import this only as optional
   search/reference aliases. Do **not** replace the TOCFL word in Simplified mode with
   those Mainland/common alternatives.

   The source workbook explicitly notes that providing a Simplified test version does
   not change the vocabulary wording used by TOCFL.

6. Preserve Pinyin exactly as supplied (apart from trimmed surrounding whitespace).
   Do not regenerate Pinyin.

7. Preserve `partOfSpeech.raw` exactly. Some official rows have no POS; keep those
   values null rather than guessing.

8. `context` is official source data only for:
   - Novice 1
   - Novice 2
   - Level 1
   - Level 2

   Level 3–5 do not have a Context column in the source. Keep `context = null`;
   do not auto-classify them.

## Recommended database shape

A single vocabulary table is enough:

```text
vocabulary_entries
- id                     PRIMARY KEY
- dataset_id             = tocfl-vocabulary-20240923
- band_id                novice | band_a | band_b | band_c
- level_id               novice_1 | novice_2 | level_1 ... level_5
- level_sequence
- global_sequence
- context                nullable
- traditional
- simplified
- pinyin
- part_of_speech_raw     nullable
- source_sheet
- source_row
```

User learning state should live in a separate table keyed by `entry_id`, for example:

```text
user_vocabulary_progress
- user_id
- entry_id
- status
- review_count
- next_review_at
- favorite
- note
```

This keeps source vocabulary immutable and prevents re-imports from destroying progress.

## Suggested UI for "Học theo Band TOCFL"

```text
Học theo Band TOCFL
   ↓
Band Novice / Band A / Band B / Band C
   ↓
Sublevel (optional filter)
   ↓
Context (only where official context exists)
   ↓
Vocabulary cards / list / review
```

For each card, display at minimum:

```text
Traditional or Simplified term
Pinyin
Part of speech (when available)
Level
Context (when available)
```

Switching Traditional/Simplified must not create a new learning item or reset progress.
Both scripts represent the same `entry.id`.

## Count discrepancy in the source workbook

Do not use the comparison worksheet `Sheet1` as the canonical source count.
It lists Novice 2 as 233, while:

- the actual `準備級二級(Novice 2)` sheet has **234** records; and
- `各等詞條數(Entry Number)` also lists **234**.

This package therefore imports **234 Novice 2 entries**.

## Import instruction

Read `catalog.json` first, validate `entries.json` against the schema, then upsert by
`entry.id`. Do not overwrite existing user progress. Treat this package as a vocabulary
dataset, not as an exam package.
